All questions are answered except for the bonus

The [TwoCenterSystem] files in this folder are meant to be run from this folder, 
not in the TwoCenterSystem folder. If you wish to change the folder, change the
include statement to: include("../../../../deps/build.jl")