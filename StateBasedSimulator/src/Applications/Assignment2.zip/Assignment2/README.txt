All questions were answered

#### BEFORE RUNNING ####
    Please move the folder 'Assignment2' to 'StateBasedSimulator\src\Applications'
    Please move the following files found in this folder to the following locations:
        - 'applications_build.jl' -> 'StateBasedSimulator\deps'
        - '[Results] ttest.jl' -> 'StateBasedSimulator\src\Results\GeneralResults'

    I found a bug in '[Results] ttest.jl' that was provided with the code from courselink.
    The '[Results] ttest.jl' that is in the Assignment2 folder should not have that bug.